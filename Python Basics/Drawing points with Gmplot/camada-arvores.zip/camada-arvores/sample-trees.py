import gmplot

mapa = gmplot.GoogleMapPlotter(-1.464997, -52.777226, 19)

# [ -1.2590629, -52.0970083 ]
# [ 0.602864, -51.877441 ]
# [ -1.464997, -52.777226 ]
# [ 37.428, -122.145 ]

latitudes = [
	-1.464997,
	-1.464852,
	-1.464790,
	-1.464950,
	-1.464925,
	-1.464910,
	-1.464510,
	-1.464615,
	-1.464635
]
longitudes = [
	-52.777226,
	-52.777046,
	-52.777150,
	-52.777280,
	-52.777114,
	-52.777195,
	-52.777195,
	-52.777100,
	-52.777054
]

# '#66FF33'
# '#33cc33'
# mapa.plot(latitudes, longitudes, 'cornflowerblue', edge_width=10)
mapa.scatter(latitudes, longitudes, '#33cc33', size=0.3, marker=False)
mapa.scatter(latitudes, longitudes, 'k', marker=True)

mapa.draw("arvores.html")